import 'package:dart_console_customer_app/dart_console_customer_app.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
