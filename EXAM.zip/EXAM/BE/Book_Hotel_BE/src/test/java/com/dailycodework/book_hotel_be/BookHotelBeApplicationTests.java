package com.dailycodework.book_hotel_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookHotelBeApplicationTests {

    @Test
    void contextLoads() {
    }

}
