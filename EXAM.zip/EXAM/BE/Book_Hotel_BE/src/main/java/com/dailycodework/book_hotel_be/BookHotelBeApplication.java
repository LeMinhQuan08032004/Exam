package com.dailycodework.book_hotel_be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookHotelBeApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookHotelBeApplication.class, args);
    }

}
